import {
  apiClient,
} from './apiClient';

import type {
  CreateTestCaseRequest,
  TestCase,
  UpdateTestCaseRequest,
} from '../types/testCase';

export const testCaseApi = {
  getByScenario(
    scenarioId: string,
  ): Promise<TestCase[]> {
    return apiClient.get<TestCase[]>(
      `/api/scenarios/${encodeURIComponent(
        scenarioId,
      )}/test-cases`,
    );
  },

  createTestCase(
    scenarioId: string,
    request: CreateTestCaseRequest,
  ): Promise<TestCase> {
    return apiClient.post<
      TestCase,
      CreateTestCaseRequest
    >(
      `/api/scenarios/${encodeURIComponent(
        scenarioId,
      )}/test-cases`,
      request,
    );
  },

  getTestCase(
    id: number,
  ): Promise<TestCase> {
    return apiClient.get<TestCase>(
      `/api/test-cases/${id}`,
    );
  },

  getTestCaseByBusinessId(
    testCaseId: string,
  ): Promise<TestCase> {
    return apiClient.get<TestCase>(
      `/api/test-cases/business/${encodeURIComponent(
        testCaseId,
      )}`,
    );
  },

  /*
   * Task 36.8
   *
   * Returns only Test Cases where:
   *
   * automatable = true
   */
  getAutomationEligible():
    Promise<TestCase[]> {
    return apiClient.get<TestCase[]>(
      '/api/test-cases/automation-eligible',
    );
  },

  updateTestCase(
    id: number,
    request: UpdateTestCaseRequest,
  ): Promise<TestCase> {
    return apiClient.put<
      TestCase,
      UpdateTestCaseRequest
    >(
      `/api/test-cases/${id}`,
      request,
    );
  },

  deleteTestCase(
    id: number,
  ): Promise<void> {
    return apiClient.delete<void>(
      `/api/test-cases/${id}`,
    );
  },
};